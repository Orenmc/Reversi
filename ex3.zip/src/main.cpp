/*
 * main.cpp
 *
 *  Created on: Oct 23, 2017
 *      Author: Oren Cohen
 *      user: cohenorx
 *      id: 305164295
 */
#include "../include/Game.h"
#include <iostream>
using namespace std;

int main() {

	Game reversi = Game();
	reversi.run();
	return 0;
}

